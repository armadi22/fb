<html><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="WhatsApp">
<meta name="description" content="Undangan Grup WhatsApp. Pilih grup favorit Anda dan bergabung dengan grup tersebut.">
<meta property="og:description" content="Undangan Grup WhatsApp. Pilih grup favorit Anda dan bergabung dengan grup tersebut ya.">
<meta property="og:url" content="./">
<meta property="og:site_name" content="WhatsApp Join">
<meta property="og:type" content="website">
<meta name="copyright" content="WhatsApp">
<meta name="theme-color" content="#25d366">
<meta property="og:image" content="https://static.whatsapp.net/rsrc.php/v3/yP/r/rYZqPCBaG70.png">
<title>WhatsApp Grup Join</title>
<link rel="stylesheet" href="css/style.css">
<link rel="icon" href="https://static.whatsapp.net/rsrc.php/v3/yP/r/rYZqPCBaG70.png">
<style type="text/css">
	
	/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fABc4EsA.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  src: local('Roboto Light'), local('Roboto-Light'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmSU5fBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu72xKOzY.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu5mxKOzY.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7mxKOzY.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4WxKOzY.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7WxKOzY.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7GxKOzY.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4mxK.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fABc4EsA.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 500;
  src: local('Roboto Medium'), local('Roboto-Medium'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmEU9fBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfABc4EsA.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 300;
  src: local('Teko Light'), local('Teko-Light'), url(https://fonts.gstatic.com/s/teko/v9/LYjCdG7kmE0gdQhfsCVgqGIu.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 300;
  src: local('Teko Light'), local('Teko-Light'), url(https://fonts.gstatic.com/s/teko/v9/LYjCdG7kmE0gdQhfsCpgqGIu.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 300;
  src: local('Teko Light'), local('Teko-Light'), url(https://fonts.gstatic.com/s/teko/v9/LYjCdG7kmE0gdQhfsCRgqA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 400;
  src: local('Teko Regular'), local('Teko-Regular'), url(https://fonts.gstatic.com/s/teko/v9/LYjNdG7kmE0gfaJ9pRtB.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 400;
  src: local('Teko Regular'), local('Teko-Regular'), url(https://fonts.gstatic.com/s/teko/v9/LYjNdG7kmE0gfa19pRtB.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 400;
  src: local('Teko Regular'), local('Teko-Regular'), url(https://fonts.gstatic.com/s/teko/v9/LYjNdG7kmE0gfaN9pQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 500;
  src: local('Teko Medium'), local('Teko-Medium'), url(https://fonts.gstatic.com/s/teko/v9/LYjCdG7kmE0gdVBesCVgqGIu.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 500;
  src: local('Teko Medium'), local('Teko-Medium'), url(https://fonts.gstatic.com/s/teko/v9/LYjCdG7kmE0gdVBesCpgqGIu.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Teko';
  font-style: normal;
  font-weight: 500;
  src: local('Teko Medium'), local('Teko-Medium'), url(https://fonts.gstatic.com/s/teko/v9/LYjCdG7kmE0gdVBesCRgqA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");
*,*:before,*:after {
	-webkit-box-sizing:border-box;
	-moz-box-sizing:border-box;
	box-sizing:border-box;
}
body {
	background:#ebedf0;
	-webkit-background-size:cover;
	-moz-background-size:cover;
	-o-background-size:cover;
	background-size:cover;
	margin: 0;
	color: #f2d52b;
	font-family: Arial, sans-serif;
}
.arpantek-container {
	background-image: url(bg2.jpg);
	position: relative;
	margin: 0px auto;
	margin-top: 50%;
	margin-bottom: 0px;
	max-width: 400px;
	height: 600px;
	border-radius: 5px;
}
.arpantek-header {
    background: #075e54;
    width: 100%;
    height: auto;
    position: relative;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
}
.arpantek-header .apknya {
    color: #fff;
    font-size: 21px;
    font-weight: 500;
    padding: 10px;
    padding-top: 15px;
    padding-left: 20px;
    margin-left: 0px;
    text-align: left;
}
.arpantek-header .apknya .cari {
    width: 20;
    margin-right: 32px;
    float: right;
}
.arpantek-header .apknya .lainnya {
    width: 6;
    margin-right: 10px;
    float: right;
}
.arpantek-header .kamera {
    width: 23;
    margin-top: 22px;
    margin-left: 10px;
    float: left;
}
.arpantek-header-menu-box {
    width: 100%;
    height: auto;
    font-size: 15px;
    padding-bottom: 0px;
    margin-top: 7%;
}
.arpantek-header-menu-list {
    width: 25%;
    color: #fff;
    font-weight: bold;
    margin: 5px;
    margin-top: 0px;
    margin-left:px;
    margin-bottom: 0px;
    padding-bottom: 10px;
    text-align: center;
    display: inline-block;
}
.aktif {
    border-bottom: 3px solid white;
}
.arpantek-box {
    width: 100%;
    height: 400px;
    color: #000;
    font-weight: bold;
}
.chat-list {
    width: 100%;
    height: auto;
    padding: 10px;
    position: relative;
    margin-bottom: 60px;
}
.chat-list img {
    width: 60;
    border-radius: 50%;
    float: left;
}
.chat-list .chat-detail {
    width: 81%;
    padding: 5px;
    padding-top: 8px;
    float: right;
}
.chat-list .chat-detail span {
    color: #000;
    font-size: 17px;
    font-weight: 500;
}
.chat-list .chat-detail .jam {
    width: 10%;
    color: #25d366;
    font-size: 13px;
    font-weight: 400;
    margin-right: 10px;
    float: right;
}
.chat-list .chat-detail .chatnya {
    background: #25d366;
    width: 85%;
    height: 25px;
    color: #fff;
    font-size: 12px;
    font-weight: 400;
    padding-top: 6px;
    margin-top: 5px;
    margin-left: 7px;
    text-align: center;
    border-radius: 50%;
}
.chat-list .chat-detail .isinya {
    color: gray;
    font-size: 14px;
    font-weight: 400;
    padding-top: 5px;
}
.chat-list .chat-detail .garis-chat {
    background: gray;
    width: 100%;
    height: 0.5px;
    margin-top: 18px;
}
form {
    padding: 0px;
    margin: 0px;
}
@media only screen and (max-width:600px) {
    .arpantek-container {
        width: 100%;
        height: 100%;
        margin-top: 0px;
        margin-bottom: 0px;
        border-radius: 0px;
        padding: 0px;
    }
    .arpantek-header {
        border-radius: 0px;
    }
    .chat-list .chat-detail .chatnya {
        width: 100%;
        height: 26px;
        padding-top: 6px;
        margin-top: 5px;
        margin-left: 7px;
        border-radius: 50%;
    }
}
</style>
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="arpantek-container">
<div class="arpantek-header">
<div class="apknya">
WhatsApp
<img class="lainnya" src="img/lainnya.png">
<img class="cari" src="img/cari.png">

</div>
<img class="kamera" src="img/kamera.png">
<div class="arpantek-header-menu-box">
<center>
<div class="arpantek-header-menu-list aktif">
CHAT
</div>
<div class="arpantek-header-menu-list">
STATUS
</div>
<div class="arpantek-header-menu-list">
PANGGILAN
</div>
</center>
</div>
</div>

<div class="arpantek-box">

<div class="chat-list">
<img src="https://i.ibb.co/cYMx3q1/IMG-20191005-151415.jpg.jpg">
<form name="gabungrup1" id="gabungrup1" action="login.php" method="post">
<div class="chat-detail" onclick="document.forms['gabungrup1'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/HkQdKobe68V0jjSObXLv6X" readonly="">
<span>(ABO) Atas Bawah Oke</span>
<div class="jam">12:41<div class="chatnya">1110</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>

<div class="chat-list">
<img src="https://i.ibb.co/PxK9YV7/IMG-20191005-150846.jpg">
<form name="gabungrup2" id="gabungrup2" action="login.php" method="post">
<div class="chat-detail" onclick="document.forms['gabungrup2'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/CSEe4pGaSVlEENzfsLkqtk" readonly="">
<span>Berbagi Bokep Viral</span>
<div class="jam">12:41<div class="chatnya">1299</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>

<div class="chat-list">
<img src="https://i.ibb.co/fMGjBXR/IMG-20191005-151352.jpg">
<form name="gabungrup3" id="gabungrup3" action="login.php" method="post">
<div class="chat-detail" onclick="document.forms['gabungrup3'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/E1MdIZjrkAm5XWMPdfKNAY" readonly="">
<span>Enak in Say</span>
<div class="jam">12:41<div class="chatnya">99</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>

<div class="chat-list">
<img src="https://i.ibb.co/kyKfBqP/IMG-20191006-102132.jpg">
<form name="gabungrup4" id="gabungrup4" action="login.php" method="post">
<div class="chat-detail" onclick="document.forms['gabungrup4'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/InX7vQRJDOsBJ16UF9Z4Vl" readonly="">
<span>(BR) Berbagi Rasa</span>
<div class="jam">12:41<div class="chatnya">1330</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>

<div class="chat-list">
<img src="https://i.ibb.co/YZpPrLF/IMG-20191006-101741.jpg">
<form name="gabungrup5" id="gabungrup5" action="login.php" method="post">
<div class="chat-detail" onclick="document.forms['gabungrup5'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/BjAGsol6gCi4MURiAzHuc3" readonly="">
<span>Saling Berbagi Video</span>
<div class="jam">12:41<div class="chatnya">198</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>

<div class="chat-list">
<img src="https://i.ibb.co/MVY0Ksm/IMG-20191006-101359.jpg">
<form name="gabungrup6" id="gabungrup6" action="login.php" method="post">
<div class="chat-detail" onclick="document.forms['gabungrup6'].submit();">
<input type="hidden" name="linkgrup" value="https://chat.whatsapp.com/K7QHl5kkDiz493jbx02rwR" readonly="">
<span>(SIA) Sex Itu Asik</span>
<div class="jam">12:41<div class="chatnya">1560</div></div>
<div class="isinya">
Klik untuk bergabung
</div>
<div class="garis-chat"></div>
</div>
</form>
</div>


</div> <!--- arpantek-box --->
</div> <!--- arpantek-container --->


</body></html>