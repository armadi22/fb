<?php
$emailkamu = "parjoedarman@gmail.com"; // Ganti dengan alamat Email lo.
?>
